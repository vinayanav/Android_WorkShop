package com.example.android.ishare;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Main2Activity extends AppCompatActivity {
    EditText editEmpid, editName, editsalary;
    Button btnAdd, btnDelete, btnModify, btnView, btnViewAll;
    SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        editEmpid = (EditText) findViewById(R.id.editEmpid);
        editName = (EditText) findViewById(R.id.editName);
        editsalary = (EditText) findViewById(R.id.editsalary);
        btnAdd = (Button) findViewById(R.id.btnAdd);
        db = openOrCreateDatabase("EmployeeDB", Context.MODE_PRIVATE, null);
        if (db != null) {
            Toast.makeText(this, "Ctreated", Toast.LENGTH_SHORT).show();
        }
        db.execSQL("CREATE TABLE IF NOT EXISTS employee(empid VARCHAR,name VARCHAR,salary VARCHAR);");

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (editEmpid.getText().toString().trim().length() == 0 ||
                        editName.getText().toString().trim().length() == 0 ||
                        editsalary.getText().toString().trim().length() == 0) {
                    showMessage("Error", "Please enter all values");
                    return;
                }
                db.execSQL("INSERT INTO employee VALUES('" + editEmpid.getText() + "','" + editName.getText() +
                        "','" + editsalary.getText() + "');");
                showMessage("Success", "Record added");
                clearText();
            }
        });



    }

    public void showMessage(String title, String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }

    public void clearText() {
        editEmpid.setText("");
        editName.setText("");
        editsalary.setText("");
        editEmpid.requestFocus();
    }

}