package com.example.android.ishare;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class Main3Activity extends AppCompatActivity {
    SQLiteDatabase db;
    ArrayList<String> name=new ArrayList<String>();
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        listView  = (ListView) findViewById(R.id.listview1);
        db = openOrCreateDatabase("EmployeeDB", Context.MODE_PRIVATE, null);
        if (db != null) {
            Toast.makeText(this, "Ctreated", Toast.LENGTH_SHORT).show();
        }
        db.execSQL("CREATE TABLE IF NOT EXISTS employee(empid VARCHAR,name VARCHAR,salary VARCHAR);");

        Cursor c = db.rawQuery("SELECT * FROM employee", null);
        int cnt=c.getCount();
        Toast.makeText(getApplicationContext(),"row count is  "+c+ "count is" +cnt,Toast.LENGTH_LONG).show();
        Log.e("msg","row count is  "+c);


        if (c.getCount() == 0) {

            showMessage("Error", "No records found");
            return;
        }
        StringBuffer buffer = new StringBuffer();
        while (c.moveToNext()) {


            String nm=c.getString(0).toString();
            String nm1=c.getString(1).toString();
            String nm2=c.getString(2).toString();


            name.add(nm+"\t \t"+nm1+"\t \t"+nm2);


        }
        ArrayAdapter<String> ad=new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_list_item_1,name);
        listView.setAdapter(ad);
        ad.notifyDataSetChanged();

    }


    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}